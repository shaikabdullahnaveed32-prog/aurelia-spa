import { createClient } from "@supabase/supabase-js";

/* ═══════════════════════════════════════════════════════════════════════
   Aurelia Spa — Supabase client.

   Uses ONLY the project's publishable (anon) key. The service_role /
   secret key is never present in this codebase — all access is governed
   by the Row Level Security policies on the `bookings` table.
   ═══════════════════════════════════════════════════════════════════════ */

const SUPABASE_URL = "https://btuupuccnxintjposvps.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_9Tgye3jU-0VkpMhrqwA0HA_45s4lim0";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

/* ── bookings ───────────────────────────────────────────────────────── */

export type BookingInsert = {
  customer_name: string;
  phone: string;
  treatment: string;
  /** ISO date string, e.g. "2026-03-14" */
  booking_date: string;
  message: string | null;
  status: "pending";
};

/** Inserts one booking request. RLS decides; we never read rows back. */
export async function createBooking(booking: BookingInsert) {
  return supabase.from("bookings").insert(booking);
}
