import { useEffect, useState } from "react";
import Atmosphere from "./components/Atmosphere";
import { Grain, Nav, Preloader } from "./components/Chrome";
import Hero from "./components/Hero";
import Ritual, { Marquee } from "./components/Ritual";
import Treatments from "./components/Treatments";
import Journey from "./components/Journey";
import Sanctuary from "./components/Sanctuary";
import { Footer, Reserve } from "./components/Reserve";

/* ═══════════════════════════════════════════════════════════════════════
   AURELIA SPA — a house of stillness told in five chapters.

   00 · The Arrival       layered, cursor-reactive hero stage
   01 · The Rituals       editorial narrative + gilded statistics
   02 · The Treatments    3D tilt cards with cursor-tracked glare
   03 · The Journey       five thresholds, image follows the hand
   04 · The Sanctuary     full-bleed scroll parallax interlude
   05 · The Reservation   magnetic seal + the house footer
   ═══════════════════════════════════════════════════════════════════════ */

export default function App() {
  const [done, setDone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDone(true), 2000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="relative min-h-screen bg-ink font-body text-cream antialiased">
      <Preloader done={done} />
      <Atmosphere />
      <Grain />
      <Nav />

      <main className="relative z-10">
        <Hero />
        <Marquee />
        <Ritual />
        <Treatments />
        <Journey />
        <Sanctuary />
        <Reserve />
      </main>

      <Footer />
    </div>
  );
}
