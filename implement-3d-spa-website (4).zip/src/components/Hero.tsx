import { useEffect, useRef } from "react";
import { Flower2 } from "lucide-react";
import { clamp, pointer, reducedMotion, useFrame } from "../motion/engine";

/* ═══════════════════════════════════════════════════════════════════════
   Hero — Chapter 00, The Arrival.

   A layered 3D stage: ghost typography behind, an arched portrait in
   the middle, gilded wordmark and bokeh in front. Every layer carries a
   data-depth; the shared loop maps the smoothed cursor onto each one at
   a different gain, so the scene floats apart as you move — like
   leaning into warm air. Scroll adds a second, slower parallax.
   ═══════════════════════════════════════════════════════════════════════ */

export default function Hero() {
  const rootRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const fadeRef = useRef<HTMLDivElement>(null);
  const layersRef = useRef<HTMLElement[]>([]);

  useEffect(() => {
    layersRef.current = Array.from(
      rootRef.current?.querySelectorAll<HTMLElement>("[data-depth]") ?? [],
    );
  }, []);

  useFrame(() => {
    const px = reducedMotion ? 0 : pointer.sx;
    const py = reducedMotion ? 0 : pointer.sy;
    const sy = window.scrollY;

    for (const node of layersRef.current) {
      const depth = parseFloat(node.dataset.depth ?? "0");
      const scroll = parseFloat(node.dataset.scroll ?? "0");
      node.style.transform = `translate3d(${px * depth * 64}px, ${
        py * depth * 44 + sy * scroll
      }px, 0)`;
    }

    if (stageRef.current) {
      stageRef.current.style.transform = `rotateY(${px * 5}deg) rotateX(${
        py * -4
      }deg)`;
    }

    if (fadeRef.current) {
      const t = clamp(sy / (window.innerHeight * 0.9), 0, 1);
      fadeRef.current.style.opacity = `${1 - t * 1.15}`;
      fadeRef.current.style.transform = `translateY(${t * -48}px)`;
    }
  });

  return (
    <section
      ref={rootRef}
      id="top"
      className="relative flex h-[100svh] min-h-[700px] items-center justify-center overflow-hidden [perspective:1400px]"
    >
      {/* warm candle-glow cores */}
      <div
        aria-hidden
        data-depth="0.012"
        className="absolute left-[calc(50%-43vmin)] top-[calc(36%-43vmin)] h-[86vmin] w-[86vmin] rounded-full bg-[radial-gradient(circle,rgba(201,164,92,0.17),transparent_62%)] blur-2xl"
      />
      <div
        aria-hidden
        data-depth="0.02"
        className="absolute -bottom-[30vmin] left-[8%] h-[60vmin] w-[60vmin] rounded-full bg-[radial-gradient(circle,rgba(140,90,40,0.14),transparent_65%)] blur-3xl"
      />

      {/* ghost typography — deepest layer */}
      <h2
        aria-hidden
        data-depth="0.018"
        data-scroll="0.05"
        className="text-outline pointer-events-none absolute top-[13%] w-full select-none whitespace-nowrap text-center font-display text-[19.5vw] font-light leading-none tracking-[0.14em]"
      >
        STILLNESS
      </h2>

      <div ref={fadeRef} className="relative flex w-full items-center justify-center [transform-style:preserve-3d]">
        {/* the arched portrait stage */}
        <div
          ref={stageRef}
          className="relative [transform-style:preserve-3d]"
        >
          <div className="enter" style={{ "--ed": "1650ms" } as React.CSSProperties}>
            <div
              className="relative"
              data-depth="0.03"
              data-scroll="0.1"
            >
              <div className="arch relative aspect-[3/4.1] w-[min(74vw,340px)] overflow-hidden border border-gold/20 shadow-[0_60px_120px_-40px_rgba(0,0,0,0.9)] sm:w-[min(52vw,390px)]">
                <div data-depth="-0.05" className="absolute -inset-[8%]">
                  <img
                    src="/images/hero-still.jpg"
                    alt="Stones, orchid and candlelight — the Aurelia still life"
                    className="h-full w-full scale-[1.06] object-cover"
                    draggable={false}
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-ink/55 via-transparent to-ink/10" />
              </div>

              {/* echo ring around the arch */}
              <div
                aria-hidden
                data-depth="0.06"
                className="arch pointer-events-none absolute -inset-4 border border-gold/30"
              />
              <div
                aria-hidden
                data-depth="0.085"
                className="arch pointer-events-none absolute -inset-9 border border-cream/8"
              />
            </div>

            {/* orbiting seal */}
            <div
              data-depth="0.12"
              className="absolute -right-14 bottom-8 hidden h-28 w-28 sm:block md:-right-20"
            >
              <div className="relative h-full w-full">
                <svg viewBox="0 0 100 100" className="spin-slow h-full w-full">
                  <defs>
                    <path
                      id="aurelia-seal"
                      d="M 50,50 m -38,0 a 38,38 0 1,1 76,0 a 38,38 0 1,1 -76,0"
                    />
                  </defs>
                  <text
                    className="fill-sand/80"
                    style={{ fontSize: "7.4px", letterSpacing: "0.3em" }}
                  >
                    <textPath href="#aurelia-seal">
                      AURELIA · RITUAL OF STILLNESS ·
                    </textPath>
                  </text>
                </svg>
                <Flower2 className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 text-gold" />
              </div>
            </div>
          </div>
        </div>

        {/* gilded wordmark — foreground layer, overlaps the arch */}
        <div
          data-depth="0.075"
          data-scroll="0.16"
          className="pointer-events-none absolute bottom-[7.5%] w-full text-center sm:bottom-[9%]"
        >
          <h1 className="font-display text-[16.5vw] leading-[0.85] tracking-[0.07em] sm:text-[13vw]">
            <span className="-mb-[0.14em] block overflow-hidden pb-[0.14em]">
              <span
                className="loader-letter text-gild"
                style={{ "--ld": "1850ms" } as React.CSSProperties}
              >
                AURELIA
              </span>
            </span>
          </h1>
          <div className="overflow-hidden">
            <p
              className="loader-letter mt-4 text-[9px] uppercase tracking-[0.55em] text-sand/90 sm:text-[11px]"
              style={{ "--ld": "2050ms" } as React.CSSProperties}
            >
              Spa · Thermal rituals · Val d&apos;Oro
            </p>
          </div>
        </div>

        {/* vertical side annotations */}
        <div
          data-depth="0.055"
          className="v-label enter absolute left-6 top-[38%] hidden text-[9px] text-muted md:block lg:left-12"
          style={{ "--ed": "2300ms" } as React.CSSProperties}
        >
          MMXXV — The house of stillness
        </div>
        <div
          data-depth="0.055"
          className="v-label enter absolute right-6 top-[46%] hidden rotate-180 text-[9px] text-muted md:block lg:right-12"
          style={{ "--ed": "2300ms" } as React.CSSProperties}
        >
          45.4642° N — 9.1900° E
        </div>

        {/* arrival note */}
        <div
          data-depth="0.045"
          className="enter absolute bottom-10 left-6 hidden max-w-[250px] lg:block xl:left-12"
          style={{ "--ed": "2450ms" } as React.CSSProperties}
        >
          <p className="text-[10px] uppercase tracking-[0.4em] text-gold">
            Chapter 00 — The Arrival
          </p>
          <p className="mt-3 text-[13px] font-light leading-relaxed text-sand/80">
            Warm stone, gilded light, unhurried hands. The world can wait
            ninety minutes.
          </p>
        </div>

        {/* scroll cue */}
        <div
          data-depth="0.04"
          className="enter absolute bottom-9 right-6 flex items-center gap-4 lg:right-12"
          style={{ "--ed": "2500ms" } as React.CSSProperties}
        >
          <span className="text-[9px] uppercase tracking-[0.4em] text-muted">
            Scroll to enter
          </span>
          <span className="scroll-line block h-12 w-px bg-cream/10">
            <span />
          </span>
        </div>

        {/* foreground bokeh */}
        <div
          aria-hidden
          data-depth="0.16"
          className="bokeh pointer-events-none absolute left-[16%] top-[24%] h-14 w-14"
        />
        <div
          aria-hidden
          data-depth="0.2"
          className="bokeh pointer-events-none absolute right-[14%] top-[58%] h-24 w-24 opacity-70"
        />
        <div
          aria-hidden
          data-depth="0.12"
          className="bokeh pointer-events-none absolute left-[30%] bottom-[16%] h-8 w-8 opacity-60"
        />
        <div
          aria-hidden
          data-depth="0.22"
          className="bokeh pointer-events-none absolute right-[30%] top-[18%] h-5 w-5 opacity-80"
        />
      </div>

      {/* floor fade into the next scene */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-ink to-transparent" />
    </section>
  );
}
