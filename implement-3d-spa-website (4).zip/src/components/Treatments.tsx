import { useRef } from "react";
import { ArrowUpRight } from "lucide-react";
import { lerp, reducedMotion, useFrame } from "../motion/engine";
import { MaskLines, Reveal } from "./Reveal";

/* ═══════════════════════════════════════════════════════════════════════
   Chapter 02 — The Treatments. Three signature doors, each a physical
   3D card: it tilts toward the cursor and a gilded glare of light
   follows across its surface.
   ═══════════════════════════════════════════════════════════════════════ */

type Treatment = {
  index: string;
  name: string;
  latin: string;
  copy: string;
  duration: string;
  price: string;
  image: string;
};

const TREATMENTS: Treatment[] = [
  {
    index: "01",
    name: "Ember Stone Ritual",
    latin: "Lapides Calidi",
    copy: "Basalt heated to the temperature of morning sun, traced along the spine until the whole back remembers how to soften.",
    duration: "75 min",
    price: "€160",
    image: "/images/treatment-stone.jpg",
  },
  {
    index: "02",
    name: "Gilded Renewal Facial",
    latin: "Aurum et Mel",
    copy: "Twenty-four-karat leaf laid over wild honey and cold-pressed gold of pleasure. The mirror will ask what happened.",
    duration: "60 min",
    price: "€140",
    image: "/images/treatment-gold.jpg",
  },
  {
    index: "03",
    name: "Moonwater Immersion",
    latin: "Aqua Lunae",
    copy: "A private mineral bath lit only by candles, orchid petals on the surface, time politely asked to wait outside.",
    duration: "90 min",
    price: "€190",
    image: "/images/treatment-bath.jpg",
  },
];

function TiltCard({ treatment, delay }: { treatment: Treatment; delay: number }) {
  const cardRef = useRef<HTMLAnchorElement>(null);
  const hovering = useRef(false);
  const target = useRef({ rx: 0, ry: 0, gx: 50, gy: 50 });
  const cur = useRef({ rx: 0, ry: 0, gx: 50, gy: 50 });

  useFrame(() => {
    const el = cardRef.current;
    if (!el) return;
    const k = hovering.current ? 0.16 : 0.07;
    cur.current.rx = lerp(cur.current.rx, target.current.rx, k);
    cur.current.ry = lerp(cur.current.ry, target.current.ry, k);
    cur.current.gx = lerp(cur.current.gx, target.current.gx, k);
    cur.current.gy = lerp(cur.current.gy, target.current.gy, k);
    el.style.transform = `rotateX(${cur.current.rx}deg) rotateY(${cur.current.ry}deg)`;
    el.style.setProperty("--gx", `${cur.current.gx}%`);
    el.style.setProperty("--gy", `${cur.current.gy}%`);
  });

  return (
    <Reveal delay={delay} className="tilt-scene">
      <a
        ref={cardRef}
        href="#reserve"
        data-cursor="View"
        className="tilt-card group relative block overflow-hidden border border-cream/12 bg-panel transition-colors duration-500 hover:border-gold/45"
        onPointerMove={(e) => {
          if (reducedMotion) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const px = (e.clientX - rect.left) / rect.width;
          const py = (e.clientY - rect.top) / rect.height;
          target.current = {
            rx: (0.5 - py) * 9,
            ry: (px - 0.5) * 11,
            gx: px * 100,
            gy: py * 100,
          };
        }}
        onPointerEnter={() => (hovering.current = true)}
        onPointerLeave={() => {
          hovering.current = false;
          target.current = { rx: 0, ry: 0, gx: 50, gy: 50 };
        }}
      >
        {/* image */}
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={treatment.image}
            alt={treatment.name}
            className="h-full w-full object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.07]"
            draggable={false}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-panel via-ink/10 to-transparent" />
          <span className="absolute left-5 top-5 rounded-full border border-cream/25 bg-ink/40 px-4 py-1.5 text-[9px] uppercase tracking-[0.3em] text-cream backdrop-blur-md">
            {treatment.latin}
          </span>
        </div>

        {/* body */}
        <div className="relative px-7 pb-8 pt-6">
          <span
            aria-hidden
            className="text-outline pointer-events-none absolute -top-9 right-5 select-none font-display text-7xl font-light"
          >
            {treatment.index}
          </span>
          <h3 className="font-display text-[1.9rem] font-light leading-tight text-cream transition-colors duration-500 group-hover:text-gold-2">
            {treatment.name}
          </h3>
          <p className="mt-3 min-h-[3.9rem] text-[13px] font-light leading-relaxed text-muted">
            {treatment.copy}
          </p>
          <div className="mt-6 flex items-center justify-between border-t border-cream/10 pt-5">
            <p className="text-[10px] uppercase tracking-[0.3em] text-sand/80">
              {treatment.duration} · {treatment.price}
            </p>
            <span className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/40 text-gold transition-all duration-500 group-hover:bg-gold group-hover:text-ink">
              <ArrowUpRight className="h-4 w-4" />
            </span>
          </div>
        </div>

        {/* cursor-tracked glare */}
        <div
          aria-hidden
          className="tilt-glare pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
        />
      </a>
    </Reveal>
  );
}

export default function Treatments() {
  return (
    <section
      id="treatments"
      className="relative overflow-hidden py-28 md:py-40"
    >
      {/* warm ambience behind the cards */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-[70vh] w-[110vw] -translate-x-1/2 bg-[radial-gradient(ellipse_at_top,rgba(201,164,92,0.07),transparent_60%)]"
      />

      <div className="relative mx-auto max-w-[1600px] px-6 md:px-12">
        <div className="grid items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-gold">
                <span className="h-px w-10 bg-gold/60" />
                02 — The Treatments
              </p>
            </Reveal>
            <MaskLines
              delay={100}
              className="mt-7 font-display text-[12vw] font-light leading-[1.02] text-cream sm:text-6xl lg:text-[4.4vw]"
              lines={[
                <>Three doors,</>,
                <>
                  one <em className="text-gild italic">stillness.</em>
                </>,
              ]}
            />
          </div>
          <Reveal delay={220} className="lg:col-span-5">
            <p className="max-w-sm text-[15px] font-light leading-relaxed text-sand/85 lg:ml-auto">
              Twelve rituals live in the house book. These three are the ones
              our guests whisper about on the way out — move your cursor
              across them, they lean in to meet you.
            </p>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3 md:gap-5 lg:gap-7">
          {TREATMENTS.map((treatment, i) => (
            <TiltCard key={treatment.index} treatment={treatment} delay={i * 130} />
          ))}
        </div>

        <Reveal delay={200} className="mt-12 flex justify-center">
          <a
            href="#journey"
            className="group inline-flex items-center gap-3 border-b border-gold/40 pb-2 text-[11px] uppercase tracking-[0.35em] text-gold transition-colors hover:border-gold hover:text-gold-2"
          >
            All twelve rituals, in order
            <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
