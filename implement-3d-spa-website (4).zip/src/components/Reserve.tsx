import { useRef, type ReactNode } from "react";
import {
  ArrowUpRight,
  AtSign,
  Flower2,
  Globe,
  Mail,
} from "lucide-react";
import { lerp, reducedMotion, useFrame } from "../motion/engine";
import { MaskLines, Reveal } from "./Reveal";
import BookingForm from "./BookingForm";

/* ═══════════════════════════════════════════════════════════════════════
   Chapter 05 — The Reservation, and the footer beneath it. The circular
   CTA is magnetic: step close and it leans toward your hand.
   ═══════════════════════════════════════════════════════════════════════ */

function Magnetic({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const target = useRef({ x: 0, y: 0 });
  const cur = useRef({ x: 0, y: 0 });

  useFrame(() => {
    const el = ref.current;
    if (!el) return;
    cur.current.x = lerp(cur.current.x, target.current.x, 0.1);
    cur.current.y = lerp(cur.current.y, target.current.y, 0.1);
    el.style.transform = `translate3d(${cur.current.x}px, ${cur.current.y}px, 0)`;
  });

  return (
    <div
      ref={ref}
      className="will-change-transform"
      onPointerMove={(e) => {
        if (reducedMotion) return;
        const rect = e.currentTarget.getBoundingClientRect();
        target.current = {
          x: (e.clientX - (rect.left + rect.width / 2)) * 0.34,
          y: (e.clientY - (rect.top + rect.height / 2)) * 0.34,
        };
      }}
      onPointerLeave={() => {
        target.current = { x: 0, y: 0 };
      }}
    >
      {children}
    </div>
  );
}

const CONTACT = [
  { label: "Hours", value: "Daily — 08:00 to 22:00" },
  { label: "Find us", value: "Via delle Terme 9, Val d'Oro" },
  { label: "Write", value: "stay@aurelia.spa" },
];

export function Reserve() {
  return (
    <section id="reserve" className="relative overflow-hidden py-32 md:py-44">
      {/* golden core glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 h-[90vmin] w-[90vmin] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(201,164,92,0.12),transparent_62%)] blur-2xl"
      />

      <div className="relative mx-auto flex max-w-[1600px] flex-col items-center px-6 text-center md:px-12">
        <Reveal>
          <p className="flex items-center justify-center gap-4 text-[10px] uppercase tracking-[0.4em] text-gold">
            <span className="h-px w-10 bg-gold/60" />
            05 — The Reservation
            <span className="h-px w-10 bg-gold/60" />
          </p>
        </Reveal>

        <MaskLines
          delay={120}
          className="mt-8 font-display text-[14vw] font-light leading-[1.0] text-cream sm:text-8xl"
          lines={[
            <>Stillness is</>,
            <>
              always <em className="text-gild italic">open.</em>
            </>,
          ]}
        />

        <Reveal delay={300} className="mt-8 max-w-md">
          <p className="text-[15px] font-light leading-relaxed text-sand/85">
            The door does not close behind you. Take the ritual whenever the
            noise gets loud — it is always the same path, and never the same
            light.
          </p>
        </Reveal>

        {/* the magnetic seal */}
        <Reveal delay={380} className="mt-14">
          <Magnetic>
            <a
              href="#booking-form"
              className="group relative flex h-44 w-44 items-center justify-center rounded-full border border-gold/45 text-gold transition-all duration-700 hover:border-gold hover:bg-gold hover:text-ink md:h-52 md:w-52"
            >
              <svg
                viewBox="0 0 100 100"
                className="spin-slow absolute inset-0 h-full w-full"
                aria-hidden
              >
                <defs>
                  <path
                    id="reserve-ring"
                    d="M 50,50 m -40,0 a 40,40 0 1,1 80,0 a 40,40 0 1,1 -80,0"
                  />
                </defs>
                <text
                  className="fill-current opacity-80"
                  style={{ fontSize: "7.1px", letterSpacing: "0.34em" }}
                >
                  <textPath href="#reserve-ring">
                    RESERVE · YOUR RITUAL ·
                  </textPath>
                </text>
              </svg>
              <ArrowUpRight className="h-8 w-8 transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:rotate-45" />
              <span className="sr-only">Reserve your ritual</span>
            </a>
          </Magnetic>
        </Reveal>

        {/* the booking book — live to Supabase */}
        <div id="booking-form" className="mt-16 w-full max-w-2xl scroll-mt-28">
          <BookingForm />
        </div>

        {/* contact strip */}
        <div className="mt-20 grid w-full max-w-4xl grid-cols-1 gap-px overflow-hidden border border-cream/10 bg-cream/10 sm:grid-cols-3">
          {CONTACT.map((item, i) => (
            <Reveal
              key={item.label}
              delay={i * 120}
              className="bg-ink/90 px-6 py-6 transition-colors duration-500 hover:bg-panel"
            >
              <p className="text-[9px] uppercase tracking-[0.4em] text-muted">
                {item.label}
              </p>
              <p className="mt-2 text-[13px] font-light text-cream/90">
                {item.value}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── footer ─────────────────────────────────────────────────────────── */

const FOOTER_LINKS = [
  { label: "Rituals", href: "#rituals" },
  { label: "Treatments", href: "#treatments" },
  { label: "Journey", href: "#journey" },
  { label: "Sanctuary", href: "#sanctuary" },
  { label: "Reserve", href: "#reserve" },
];

export function Footer() {
  return (
    <footer className="relative z-10 overflow-hidden border-t border-cream/10 bg-coal/70 backdrop-blur-sm">
      <div className="mx-auto max-w-[1600px] px-6 pb-10 pt-16 md:px-12">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <a href="#top" className="flex items-center gap-3.5">
              <Flower2 className="h-5 w-5 text-gold" />
              <span className="font-display text-2xl tracking-[0.3em] text-cream">
                AURELIA
              </span>
            </a>
            <p className="mt-5 max-w-xs text-[13px] font-light leading-relaxed text-muted">
              A house of stillness in the Val d&apos;Oro. Thermal rituals,
              gilded touch, and ninety minutes out of time.
            </p>
          </div>

          <div className="md:col-span-3">
            <p className="text-[9px] uppercase tracking-[0.4em] text-muted">
              Explore
            </p>
            <ul className="mt-5 space-y-3">
              {FOOTER_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="group inline-flex items-center gap-3 text-[13px] font-light text-sand/85 transition-colors hover:text-gold-2"
                  >
                    <span className="h-px w-4 bg-gold/50 transition-all duration-500 group-hover:w-7 group-hover:bg-gold" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <p className="text-[9px] uppercase tracking-[0.4em] text-muted">
              The quiet letter
            </p>
            <p className="mt-5 text-[13px] font-light leading-relaxed text-muted">
              One envelope a season. Openings, new rituals, nothing else.
            </p>
            <form
              className="mt-5 flex max-w-sm items-center border-b border-cream/20 pb-2 transition-colors focus-within:border-gold"
              onSubmit={(e) => e.preventDefault()}
            >
              <input
                type="email"
                required
                placeholder="your@address.com"
                className="w-full bg-transparent text-[13px] font-light text-cream placeholder:text-muted/70 focus:outline-none"
              />
              <button
                type="submit"
                aria-label="Subscribe"
                className="text-gold transition-transform duration-500 hover:translate-x-1"
              >
                <ArrowUpRight className="h-4 w-4" />
              </button>
            </form>
            <div className="mt-7 flex gap-3">
              {[AtSign, Globe, Mail].map((Icon, i) => (
                <a
                  key={i}
                  href="#top"
                  aria-label="Social link"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-cream/15 text-sand/80 transition-all duration-400 hover:border-gold/60 hover:text-gold"
                >
                  <Icon className="h-3.5 w-3.5" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* monumental ghost wordmark */}
      <div aria-hidden className="pointer-events-none relative select-none">
        <p className="text-outline -mb-[4.5vw] text-center font-display text-[19vw] font-light leading-[0.78] tracking-[0.1em]">
          AURELIA
        </p>
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <div className="relative border-t border-cream/10">
        <div className="mx-auto flex max-w-[1600px] flex-col items-center justify-between gap-3 px-6 py-6 text-[9px] uppercase tracking-[0.35em] text-muted sm:flex-row md:px-12">
          <p>© MMXXV Aurelia Spa</p>
          <p className="flex items-center gap-3">
            <span className="diamond opacity-60" />
            Crafted in stillness
            <span className="diamond opacity-60" />
          </p>
          <p>Privacy — Terms</p>
        </div>
      </div>
    </footer>
  );
}
