import { useEffect, useState, type CSSProperties } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { cn } from "../utils/cn";

/* ═══════════════════════════════════════════════════════════════════════
   Chrome — the persistent shell: preloader curtain, film grain,
   a two-part custom cursor, and the fixed navigation.
   ═══════════════════════════════════════════════════════════════════════ */

const NAV_LINKS = [
  { label: "Rituals", href: "#rituals", index: "01" },
  { label: "Treatments", href: "#treatments", index: "02" },
  { label: "Journey", href: "#journey", index: "03" },
  { label: "Sanctuary", href: "#sanctuary", index: "04" },
];

/* ── preloader ──────────────────────────────────────────────────────── */

export function Preloader({ done }: { done: boolean }) {
  const [gone, setGone] = useState(false);

  useEffect(() => {
    if (!done) return;
    const t = setTimeout(() => setGone(true), 950);
    return () => clearTimeout(t);
  }, [done]);

  if (gone) return null;

  return (
    <div
      aria-hidden
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink",
        "transition-transform duration-[950ms] ease-[cubic-bezier(0.7,0,0.2,1)]",
        done && "-translate-y-full",
      )}
    >
      <p className="mb-5 text-[10px] uppercase tracking-[0.55em] text-muted">
        The house of stillness
      </p>
      <div className="overflow-hidden">
        <h1 className="font-display text-[15vw] leading-none tracking-[0.16em] text-cream sm:text-7xl">
          {"AURELIA".split("").map((letter, i) => (
            <span
              key={i}
              className="loader-letter"
              style={{ "--ld": `${120 + i * 70}ms` } as CSSProperties}
            >
              {letter}
            </span>
          ))}
        </h1>
      </div>
      <div className="loader-line mt-7 h-px w-40 bg-gold/70" />
      <p className="mt-5 text-[10px] uppercase tracking-[0.4em] text-gold/80">
        Spa · MMXXV
      </p>
    </div>
  );
}

/* ── film grain ─────────────────────────────────────────────────────── */

const GRAIN = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;

export function Grain() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-[80] opacity-[0.05] mix-blend-soft-light"
      style={{ backgroundImage: GRAIN }}
    />
  );
}

/* ── navigation ─────────────────────────────────────────────────────── */

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-[70] transition-all duration-700",
          scrolled
            ? "border-b border-cream/10 bg-ink/72 backdrop-blur-xl"
            : "border-b border-transparent bg-transparent",
        )}
      >
        <nav className="mx-auto flex max-w-[1600px] items-center justify-between px-6 py-4 md:px-12 md:py-5">
          <a href="#top" className="group flex items-center gap-3.5">
            <span className="diamond transition-transform duration-500 group-hover:rotate-[135deg]" />
            <span className="leading-none">
              <span className="block font-display text-xl tracking-[0.34em] text-cream">
                AURELIA
              </span>
              <span className="mt-1 block text-[8px] uppercase tracking-[0.5em] text-muted">
                Spa &amp; Rituals
              </span>
            </span>
          </a>

          <ul className="hidden items-center gap-9 lg:flex">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="group relative text-[11px] uppercase tracking-[0.3em] text-sand/80 transition-colors duration-300 hover:text-cream"
                >
                  <span className="mr-1.5 text-[8px] text-gold/70">
                    {link.index}
                  </span>
                  {link.label}
                  <span className="absolute -bottom-1.5 left-0 h-px w-full origin-right scale-x-0 bg-gold transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:origin-left group-hover:scale-x-100" />
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-4">
            <a
              href="#reserve"
              className="group hidden items-center gap-2 rounded-full border border-gold/50 px-5 py-2.5 text-[10px] uppercase tracking-[0.3em] text-gold transition-all duration-500 hover:bg-gold hover:text-ink sm:flex"
            >
              Reserve
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/15 text-cream transition-colors duration-300 hover:border-gold/60 hover:text-gold lg:hidden"
            >
              <Menu className="h-4 w-4" />
            </button>
          </div>
        </nav>
      </header>

      {/* mobile overlay menu */}
      <div
        className={cn(
          "fixed inset-0 z-[75] flex flex-col bg-ink/97 backdrop-blur-2xl transition-all duration-700 ease-[cubic-bezier(0.7,0,0.2,1)] lg:hidden",
          open
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0",
        )}
      >
        <div className="flex items-center justify-between px-6 py-4">
          <span className="font-display text-xl tracking-[0.34em] text-cream">
            AURELIA
          </span>
          <button
            onClick={() => setOpen(false)}
            aria-label="Close menu"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/15 text-cream transition-colors hover:border-gold/60 hover:text-gold"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <nav className="flex flex-1 flex-col justify-center gap-2 px-8">
          {NAV_LINKS.map((link, i) => (
            <div key={link.href} className="overflow-hidden">
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "group flex items-baseline gap-4 py-2 transition-all duration-700",
                  open ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0",
                )}
                style={{ transitionDelay: `${140 + i * 80}ms` }}
              >
                <span className="text-[10px] tracking-[0.3em] text-gold/70">
                  {link.index}
                </span>
                <span className="font-display text-5xl text-cream transition-colors group-hover:text-gold">
                  {link.label}
                </span>
              </a>
            </div>
          ))}
          <div className="overflow-hidden">
            <a
              href="#reserve"
              onClick={() => setOpen(false)}
              className={cn(
                "mt-6 inline-flex items-center gap-3 border-b border-gold/60 pb-2 text-[11px] uppercase tracking-[0.35em] text-gold transition-all duration-700",
                open ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0",
              )}
              style={{ transitionDelay: "520ms" }}
            >
              Reserve your ritual <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </nav>
        <p className="px-8 pb-8 text-[9px] uppercase tracking-[0.4em] text-muted">
          Val d&apos;Oro — Daily 08–22
        </p>
      </div>
    </>
  );
}
