import { useEffect, useRef } from "react";
import { ArrowRight } from "lucide-react";
import { clamp, reducedMotion, useDepthParallax } from "../motion/engine";
import { MaskLines, Reveal } from "./Reveal";

/* ═══════════════════════════════════════════════════════════════════════
   Chapter 01 — The Rituals. Editorial split: narrative and statistics
   on the left, a cursor-reactive still-life composition on the right.
   ═══════════════════════════════════════════════════════════════════════ */

const STATS: { value?: number; literal?: string; label: string }[] = [
  { value: 12, label: "Signature rituals" },
  { value: 90, label: "Minutes a ritual" },
  { value: 27, label: "Botanicals in the blend" },
  { literal: "∞", label: "Hurry, anywhere" },
];

function CountUp({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (reducedMotion) {
      el.textContent = `${value}`;
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        io.disconnect();
        const t0 = performance.now();
        const duration = 1900;
        const tick = (t: number) => {
          const p = clamp((t - t0) / duration, 0, 1);
          el.textContent = `${Math.round(value * (1 - Math.pow(1 - p, 4)))}`;
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.5 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [value]);

  return <span ref={ref}>0</span>;
}

export default function Ritual() {
  const stageRef = useDepthParallax<HTMLDivElement>();

  return (
    <section id="rituals" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto grid max-w-[1600px] items-center gap-16 px-6 md:px-12 lg:grid-cols-12 lg:gap-10">
        {/* narrative column */}
        <div className="relative lg:col-span-5">
          <Reveal>
            <p className="flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-gold">
              <span className="h-px w-10 bg-gold/60" />
              01 — The Rituals
            </p>
          </Reveal>

          <MaskLines
            className="mt-7 font-display text-[13vw] font-light leading-[1.02] text-cream sm:text-6xl lg:text-[4.4vw]"
            lines={[
              <>Ninety minutes,</>
              ,
              <>
                gently <em className="text-gild italic">out of time.</em>
              </>,
            ]}
          />

          <Reveal delay={240} className="mt-8 max-w-md">
            <p className="text-[15px] font-light leading-relaxed text-sand/85">
              Aurelia begins where the phone goes dark: a low lit room of warm
              travertine, water held at body temperature, oil warmed between
              two palms before it ever touches you. Nothing here is a
              treatment. Everything is a threshold.
            </p>
            <p className="mt-5 text-[15px] font-light leading-relaxed text-muted">
              Each ritual follows the old rhythm — warm, anoint, stone, steam,
              rest — the order the body already knows, slowed until you can
              hear it.
            </p>
          </Reveal>

          <Reveal delay={340} className="mt-9">
            <a
              href="#journey"
              className="group inline-flex items-center gap-3 text-[11px] uppercase tracking-[0.32em] text-gold transition-colors hover:text-gold-2"
            >
              Follow the journey
              <ArrowRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1.5" />
            </a>
          </Reveal>

          {/* statistics */}
          <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden border border-cream/10 bg-cream/10">
            {STATS.map((stat, i) => (
              <Reveal
                key={stat.label}
                delay={i * 120}
                className="bg-ink px-6 py-7 transition-colors duration-500 hover:bg-panel"
              >
                <p className="font-display text-4xl font-light text-gold-2 md:text-5xl">
                  {stat.literal ?? <CountUp value={stat.value ?? 0} />}
                </p>
                <p className="mt-2 text-[10px] uppercase tracking-[0.3em] text-muted">
                  {stat.label}
                </p>
              </Reveal>
            ))}
          </div>
        </div>

        {/* parallax composition column */}
        <div
          ref={stageRef}
          className="relative mx-auto w-full max-w-[560px] lg:col-span-7 [perspective:1200px]"
        >
          {/* ghost numeral */}
          <span
            aria-hidden
            data-depth="0.025"
            className="text-outline pointer-events-none absolute -top-16 left-0 select-none font-display text-[11rem] font-light leading-none md:text-[15rem]"
          >
            01
          </span>

          <Reveal className="relative ml-auto w-[76%]">
            <div data-depth="0.03" className="relative">
              <div className="relative aspect-[4/5] overflow-hidden border border-cream/12 shadow-[0_60px_110px_-40px_rgba(0,0,0,0.85)]">
                <div data-depth="-0.05" className="absolute -inset-[7%]">
                  <img
                    src="/images/ritual-hands.jpg"
                    alt="Golden oil poured by a therapist's hands"
                    className="h-full w-full object-cover"
                    draggable={false}
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-ink/40 via-transparent to-transparent" />
              </div>
              <div
                aria-hidden
                data-depth="0.055"
                className="pointer-events-none absolute -inset-3 border border-gold/25"
              />
            </div>
          </Reveal>

          {/* secondary polaroid */}
          <Reveal
            delay={180}
            className="absolute -bottom-10 left-0 w-[46%] sm:w-[42%]"
          >
            <div data-depth="0.085" className="drift">
              <div className="relative aspect-[4/3] overflow-hidden border border-cream/12 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.9)]">
                <img
                  src="/images/treatment-bath.jpg"
                  alt="Candle-lit moonwater bath"
                  className="h-full w-full object-cover"
                  draggable={false}
                />
                <div className="absolute inset-0 bg-ink/15" />
              </div>
            </div>
          </Reveal>

          {/* floating caption */}
          <div
            data-depth="0.13"
            className="absolute right-[4%] top-[16%] max-w-[180px]"
          >
            <div className="border border-cream/12 bg-ink/72 px-5 py-4 backdrop-blur-md">
              <p className="text-[13px] font-light italic leading-snug text-gold-2">
                &ldquo;Oil is poured slowly, the way you would pour for a
                guest you love.&rdquo;
              </p>
              <p className="mt-2 text-[9px] uppercase tracking-[0.3em] text-muted">
                House notes
              </p>
            </div>
          </div>

          {/* orbiting dashed ring */}
          <div
            aria-hidden
            data-depth="0.06"
            className="pointer-events-none absolute -left-12 top-[38%] hidden h-40 w-40 md:block"
          >
            <div className="spin-slower h-full w-full rounded-full border border-dashed border-gold/30" />
            <div className="absolute left-1/2 top-0 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── the gilded marquee ─────────────────────────────────────────────── */

const WORDS = [
  "Stillness",
  "Warmth",
  "Renewal",
  "Breath",
  "Gold",
  "Ritual",
  "Silence",
  "Light",
];

export function Marquee() {
  return (
    <div className="relative overflow-hidden border-y border-cream/10 bg-coal/50 py-7 backdrop-blur-[2px]">
      <div className="marquee-track">
        {[0, 1].map((half) => (
          <div key={half} aria-hidden={half === 1} className="flex items-center">
            {WORDS.map((word) => (
              <span key={`${half}-${word}`} className="flex items-center">
                <span className="mx-9 whitespace-nowrap font-display text-4xl font-light italic text-cream/70 md:text-5xl">
                  {word}
                </span>
                <span className="diamond opacity-60" />
              </span>
            ))}
          </div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink to-transparent" />
    </div>
  );
}
