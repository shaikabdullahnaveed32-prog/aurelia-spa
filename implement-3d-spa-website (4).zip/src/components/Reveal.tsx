import type { CSSProperties, ReactNode } from "react";
import { cn } from "../utils/cn";
import { useInView } from "../motion/engine";

/* ── fade / rise reveal ─────────────────────────────────────────────── */

export function Reveal({
  className,
  delay = 0,
  children,
  id,
}: {
  className?: string;
  delay?: number;
  children: ReactNode;
  id?: string;
}) {
  const ref = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      id={id}
      className={cn("reveal", className)}
      style={{ "--rd": `${delay}ms` } as CSSProperties}
    >
      {children}
    </div>
  );
}

/* ── hairline that draws itself ─────────────────────────────────────── */

export function RevealLine({
  className,
  delay = 0,
}: {
  className?: string;
  delay?: number;
}) {
  const ref = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      aria-hidden
      className={cn("reveal-line h-px bg-cream/15", className)}
      style={{ "--rd": `${delay}ms` } as CSSProperties}
    />
  );
}

/* ── masked line-by-line display text ───────────────────────────────── */

export function MaskLines({
  lines,
  className,
  lineClassName,
  delay = 0,
}: {
  lines: ReactNode[];
  className?: string;
  lineClassName?: string;
  delay?: number;
}) {
  const ref = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className={className}>
      {lines.map((line, i) => (
        <span
          key={i}
          className="-mb-[0.14em] block overflow-hidden pb-[0.14em]"
        >
          <span
            className={cn("mask-span", lineClassName)}
            style={{ "--rd": `${delay + i * 120}ms` } as CSSProperties}
          >
            {line}
          </span>
        </span>
      ))}
    </div>
  );
}
