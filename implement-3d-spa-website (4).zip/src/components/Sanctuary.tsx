import { useRef } from "react";
import { clamp, pointer, reducedMotion, useFrame } from "../motion/engine";
import { MaskLines, Reveal } from "./Reveal";

/* ═══════════════════════════════════════════════════════════════════════
   Chapter 04 — The Sanctuary. A full-bleed cinematic interlude: the
   pool breathes past at its own speed while the ghost word and the
   photograph slide on separate axes under the cursor.
   ═══════════════════════════════════════════════════════════════════════ */

export default function Sanctuary() {
  const sectionRef = useRef<HTMLElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const wordRef = useRef<HTMLHeadingElement>(null);

  useFrame(() => {
    const section = sectionRef.current;
    const img = imgRef.current;
    if (!section || !img) return;

    const rect = section.getBoundingClientRect();
    const vh = window.innerHeight;
    const progress = clamp((vh - rect.top) / (vh + rect.height), 0, 1);
    const px = reducedMotion ? 0 : pointer.sx;
    const py = reducedMotion ? 0 : pointer.sy;

    img.style.transform = `translate3d(${px * 30}px, ${
      (progress - 0.5) * 13
    }%, 0) scale(1.16)`;

    if (wordRef.current) {
      wordRef.current.style.transform = `translate3d(calc(-50% + ${
        px * -40
      }px), calc(-50% + ${(progress - 0.5) * -70 + py * -20}px), 0)`;
    }
  });

  return (
    <section
      ref={sectionRef}
      id="sanctuary"
      className="relative flex h-[105svh] min-h-[640px] items-center justify-center overflow-hidden"
    >
      {/* the photograph — oversized for dual-axis parallax */}
      <div className="absolute inset-[-12%]">
        <img
          ref={imgRef}
          src="/images/sanctuary.jpg"
          alt="The Aurelia sanctuary — a candle-lit black stone pool"
          className="h-full w-full object-cover will-change-transform"
          draggable={false}
        />
      </div>

      {/* cinematic scrims */}
      <div className="absolute inset-0 bg-ink/38" />
      <div className="absolute inset-x-0 top-0 h-44 bg-gradient-to-b from-ink to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-ink to-transparent" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(10,8,6,0.55)_100%)]" />

      {/* ghost word drifting on its own axis */}
      <h2
        ref={wordRef}
        aria-hidden
        className="text-outline-gold pointer-events-none absolute left-1/2 top-1/2 select-none whitespace-nowrap font-display text-[16vw] font-light leading-none tracking-[0.12em]"
      >
        SANCTUARY
      </h2>

      {/* the house quote */}
      <div className="relative z-10 max-w-4xl px-6 text-center">
        <Reveal>
          <p className="text-[10px] uppercase tracking-[0.45em] text-gold">
            04 — The Sanctuary
          </p>
        </Reveal>
        <MaskLines
          delay={150}
          className="mt-8 font-display text-[9.5vw] font-light italic leading-[1.12] text-cream sm:text-5xl lg:text-6xl"
          lines={[
            <>&ldquo;The light does not</>,
            <>
              hurry <span className="text-gild not-italic">here.</span>&rdquo;
            </>,
          ]}
        />
        <Reveal delay={420} className="mt-9">
          <p className="text-[10px] uppercase tracking-[0.4em] text-sand/75">
            House notes — carved stone, still water, one long breath
          </p>
        </Reveal>
      </div>

      {/* corner captions */}
      <p className="absolute bottom-8 left-6 z-10 text-[9px] uppercase tracking-[0.4em] text-cream/60 md:left-12">
        Open daily — 08:00 to 22:00
      </p>
      <p className="absolute bottom-8 right-6 z-10 text-[9px] uppercase tracking-[0.4em] text-cream/60 md:right-12">
        Val d&apos;Oro — Est. MMXXV
      </p>
    </section>
  );
}
