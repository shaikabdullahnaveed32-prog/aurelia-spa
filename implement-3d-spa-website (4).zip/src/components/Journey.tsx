import { useRef, useState } from "react";
import { clamp, lerp, reducedMotion, useFrame } from "../motion/engine";
import { MaskLines, Reveal } from "./Reveal";

/* ═══════════════════════════════════════════════════════════════════════
   Chapter 03 — The Journey. Five thresholds in the house order. Rest
   the cursor on any row and a small candle-lit preview of that moment
   rises out of the dark and follows your hand.
   ═══════════════════════════════════════════════════════════════════════ */

type Step = {
  index: string;
  title: string;
  copy: string;
  duration: string;
  image: string;
};

const STEPS: Step[] = [
  {
    index: "01",
    title: "The Arrival",
    copy: "Shoes off, phone asleep, warm towel and cooler tea. The house takes your coat and your noise in the same motion.",
    duration: "10 min",
    image: "/images/hero-still.jpg",
  },
  {
    index: "02",
    title: "The Unbinding",
    copy: "Guided breath in the candle court — four counts in, six out, until the shoulders drop of their own accord.",
    duration: "15 min",
    image: "/images/treatment-bath.jpg",
  },
  {
    index: "03",
    title: "The Anointing",
    copy: "Golden oil, warmed between palms, poured slowly across the back. The oldest sentence in the house.",
    duration: "30 min",
    image: "/images/ritual-hands.jpg",
  },
  {
    index: "04",
    title: "Stone & Steam",
    copy: "Heated basalt along the spine while eucalyptus steam rewrites the air. Most guests stop keeping time here.",
    duration: "25 min",
    image: "/images/treatment-stone.jpg",
  },
  {
    index: "05",
    title: "The Gilding",
    copy: "Gold leaf and honey pressed to the face, then ten minutes of nothing at all. Leave with one thing worth keeping.",
    duration: "10 min",
    image: "/images/treatment-gold.jpg",
  },
];

export default function Journey() {
  const zoneRef = useRef<HTMLDivElement>(null);
  const floatRef = useRef<HTMLDivElement>(null);
  const imgRefs = useRef<(HTMLImageElement | null)[]>([]);
  const pos = useRef({ x: 0, y: 0 });
  const cur = useRef({ x: 0, y: 0 });
  const shown = useRef(0);
  const [active, setActive] = useState<number | null>(null);

  useFrame(() => {
    const el = floatRef.current;
    if (!el) return;
    cur.current.x = lerp(cur.current.x, pos.current.x, 0.11);
    cur.current.y = lerp(cur.current.y, pos.current.y, 0.11);
    const target = active === null || reducedMotion ? 0 : 1;
    shown.current = lerp(shown.current, target, 0.09);

    const tilt = clamp(
      (pos.current.x - cur.current.x) * 0.045 * shown.current,
      -7,
      7,
    );
    const scale = 0.82 + shown.current * 0.18;
    el.style.opacity = `${shown.current}`;
    el.style.transform = `translate3d(${cur.current.x}px, ${cur.current.y}px, 0) translate(-50%, -58%) rotate(${tilt}deg) scale(${scale})`;

    imgRefs.current.forEach((img, i) => {
      if (img) img.style.opacity = i === active ? "1" : "0";
    });
  });

  return (
    <section id="journey" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto max-w-[1600px] px-6 md:px-12">
        <div className="grid items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-gold">
                <span className="h-px w-10 bg-gold/60" />
                03 — The Journey
              </p>
            </Reveal>
            <MaskLines
              delay={100}
              className="mt-7 font-display text-[12vw] font-light leading-[1.02] text-cream sm:text-6xl lg:text-[4.4vw]"
              lines={[
                <>One path,</>,
                <>
                  five <em className="text-gild italic">thresholds.</em>
                </>,
              ]}
            />
          </div>
          <Reveal delay={220} className="lg:col-span-5">
            <p className="max-w-sm text-[15px] font-light leading-relaxed text-sand/85 lg:ml-auto">
              Every ritual is a walk, not a lecture. You arrive, you soften,
              you glow — ninety minutes in the order the body already knows.
            </p>
          </Reveal>
        </div>

        {/* the five thresholds */}
        <div ref={zoneRef} className="relative mt-16 lg:mt-20" onPointerLeave={() => setActive(null)}>
          {STEPS.map((step, i) => (
            <Reveal key={step.index} delay={i * 90}>
              <a
                href="#reserve"
                data-cursor="Begin"
                className="journey-row group relative grid grid-cols-[auto_1fr_auto] items-center gap-5 border-t border-cream/10 py-7 transition-colors duration-500 last:border-b hover:border-gold/30 md:grid-cols-[70px_1fr_minmax(0,360px)_120px] md:gap-8 md:py-9"
                onPointerMove={(e) => {
                  const rect = zoneRef.current?.getBoundingClientRect();
                  if (!rect) return;
                  pos.current = {
                    x: e.clientX - rect.left,
                    y: e.clientY - rect.top,
                  };
                }}
                onPointerEnter={(e) => {
                  const rect = zoneRef.current?.getBoundingClientRect();
                  if (rect) {
                    pos.current = {
                      x: e.clientX - rect.left,
                      y: e.clientY - rect.top,
                    };
                    // first appearance: snap to the hand instead of gliding in from afar
                    if (shown.current < 0.06) cur.current = { ...pos.current };
                  }
                  setActive(i);
                }}
                onFocus={() => setActive(i)}
                onBlur={() => setActive(null)}
              >
                <span className="text-[11px] tracking-[0.3em] text-gold/80 transition-colors duration-300 group-hover:text-gold">
                  {step.index}
                </span>
                <h3 className="row-title font-display text-[7.4vw] font-light leading-none text-cream transition-colors duration-500 group-hover:text-gold-2 sm:text-4xl lg:text-[3.4rem]">
                  {step.title}
                </h3>
                <p className="hidden text-[12.5px] font-light leading-relaxed text-muted transition-colors duration-500 group-hover:text-sand/80 md:block">
                  {step.copy}
                </p>
                <span className="text-right text-[10px] uppercase tracking-[0.3em] text-muted transition-colors duration-300 group-hover:text-cream">
                  {step.duration}
                </span>
              </a>
            </Reveal>
          ))}

          {/* the floating preview that follows the cursor */}
          <div
            ref={floatRef}
            aria-hidden
            className="pointer-events-none absolute left-0 top-0 z-20 hidden w-48 opacity-0 md:block lg:w-56"
          >
            <div className="arch relative aspect-[3/4] overflow-hidden border border-gold/35 shadow-[0_50px_90px_-30px_rgba(0,0,0,0.95)]">
              {STEPS.map((step, i) => (
                <img
                  key={step.index}
                  ref={(el) => {
                    imgRefs.current[i] = el;
                  }}
                  src={step.image}
                  alt=""
                  className="absolute inset-0 h-full w-full object-cover transition-opacity duration-300"
                  style={{ opacity: 0 }}
                  draggable={false}
                />
              ))}
              <div className="absolute inset-0 bg-gradient-to-t from-ink/45 via-transparent to-transparent" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
