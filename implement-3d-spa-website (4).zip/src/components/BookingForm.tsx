import { useRef, useState, type FormEvent } from "react";
import {
  AlertCircle,
  CalendarDays,
  Check,
  ChevronDown,
  LoaderCircle,
  Phone,
  Sparkles,
  User,
} from "lucide-react";
import { createBooking } from "../lib/supabase";
import { cn } from "../utils/cn";
import { Reveal, RevealLine } from "./Reveal";

/* ═══════════════════════════════════════════════════════════════════════
   The booking book — a real reservation form bound to the Supabase
   `bookings` table. Every submission is a live INSERT; nothing here is
   simulated. Success and failure are both said out loud.

   Guarantees:
   · friendly field-level validation before anything leaves the page
   · whitespace-only input can never pass as content
   · a ref lock + disabled button make a duplicate in-flight INSERT
     impossible, however quickly the form is re-fired
   · fields are wiped the moment the house accepts the booking
   ═══════════════════════════════════════════════════════════════════════ */

const TREATMENTS = [
  "Ember Stone Ritual",
  "Gilded Renewal Facial",
  "Moonwater Immersion",
  "The Full Journey — five thresholds",
  "House's choice — the therapists decide",
] as const;

const MESSAGE_LIMIT = 500;

type Status = "idle" | "sending" | "success" | "error";
type FieldKey = "name" | "phone" | "treatment" | "date" | "message";
type FieldErrors = Partial<Record<FieldKey, string>>;

type FormValues = {
  name: string;
  phone: string;
  treatment: string;
  date: string;
  message: string;
};

type Confirmation = Omit<FormValues, "message">;

/* ── validation ─────────────────────────────────────────────────────── */

export function validateBooking(values: FormValues): FieldErrors {
  const errors: FieldErrors = {};

  const name = values.name.trim();
  if (!name) {
    errors.name = "We would love to know your name.";
  } else if (name.length < 2) {
    errors.name = "A name needs at least two letters.";
  } else if (name.length > 100) {
    errors.name = "A shorter name will do beautifully.";
  }

  const phone = values.phone.trim();
  const digits = phone.replace(/\D/g, "");
  if (!phone) {
    errors.phone = "The house confirms every booking by telephone.";
  } else if (!/^\+?[0-9\s().-]*$/.test(phone) || phone.includes("--")) {
    errors.phone = "Only digits, spaces and a leading + , please.";
  } else if (digits.length < 7 || digits.length > 15) {
    errors.phone = "This number does not look reachable — check it once more.";
  }

  if (!values.treatment) {
    errors.treatment = "Choose the door you wish to walk through.";
  } else if (!(TREATMENTS as readonly string[]).includes(values.treatment)) {
    errors.treatment = "Choose a ritual from the house book.";
  }

  if (!values.date) {
    errors.date = "Tell us the day of your visit.";
  } else if (Number.isNaN(new Date(`${values.date}T12:00:00`).getTime())) {
    errors.date = "That day does not exist on the calendar.";
  } else if (values.date < new Date().toISOString().split("T")[0]) {
    errors.date = "Choose a day still ahead of us.";
  }

  if (values.message.trim().length > MESSAGE_LIMIT) {
    errors.message = `Keep the note under ${MESSAGE_LIMIT} characters.`;
  }

  return errors;
}

/* ── styling ────────────────────────────────────────────────────────── */

const fieldClass =
  "w-full rounded-none border-b border-cream/20 bg-transparent py-2.5 pr-8 text-[14px] font-light text-cream placeholder:text-muted/55 transition-colors duration-500 focus:border-gold focus:outline-none";

const fieldErrorClass = "border-[#d98a6a]/70 focus:border-[#e5a98f]";

const labelClass =
  "mb-1.5 block text-[9px] uppercase tracking-[0.38em] text-muted";

function FieldIcon({ icon: Icon }: { icon: typeof User }) {
  return (
    <Icon className="pointer-events-none absolute bottom-3 right-1 h-3.5 w-3.5 text-muted/70" />
  );
}

function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p
      role="alert"
      className="mt-1.5 text-[11px] font-light leading-snug tracking-[0.03em] text-[#e5a98f]"
    >
      {message}
    </p>
  );
}

/* ── the form ───────────────────────────────────────────────────────── */

export default function BookingForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [treatment, setTreatment] = useState("");
  const [date, setDate] = useState("");
  const [message, setMessage] = useState("");

  const [status, setStatus] = useState<Status>("idle");
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<Confirmation | null>(null);

  /* lock that makes a second in-flight INSERT physically impossible —
     independent of re-renders, double clicks and impatient Enter keys */
  const sendingRef = useRef(false);

  const today = new Date().toISOString().split("T")[0];

  function clearFieldError(key: FieldKey) {
    setFieldErrors((prev) =>
      prev[key] ? { ...prev, [key]: undefined } : prev,
    );
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (sendingRef.current) return;

    /* 1 · client-side gate — nothing empty or invalid ever leaves */
    const errors = validateBooking({ name, phone, treatment, date, message });
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setStatus("idle");
      const first = (["name", "phone", "treatment", "date", "message"] as FieldKey[]).find(
        (key) => errors[key],
      );
      if (first) document.getElementById(`booking-${first}`)?.focus();
      return;
    }
    setFieldErrors({});

    /* 2 · take the lock, then write to the house book */
    sendingRef.current = true;
    setStatus("sending");
    setErrorMessage(null);

    const booking = {
      customer_name: name.trim(),
      phone: phone.trim(),
      treatment,
      booking_date: date,
      message: message.trim() || null,
      status: "pending" as const,
    };

    try {
      const { error } = await createBooking(booking);
      if (error) {
        setStatus("error");
        setErrorMessage(error.message);
        return;
      }

      /* success — keep a snapshot for the confirmation, then wipe the
         form so a fresh guest always faces a fresh page */
      setConfirmation({
        name: booking.customer_name,
        phone: booking.phone,
        treatment: booking.treatment,
        date: booking.booking_date,
      });
      setName("");
      setPhone("");
      setTreatment("");
      setDate("");
      setMessage("");
      setFieldErrors({});
      setStatus("success");
    } catch (err) {
      setStatus("error");
      setErrorMessage(
        err instanceof Error
          ? err.message
          : "The wire to the house was interrupted.",
      );
    } finally {
      sendingRef.current = false;
    }
  }

  function resetForm() {
    setConfirmation(null);
    setErrorMessage(null);
    setFieldErrors({});
    setStatus("idle");
  }

  const prettyDate = (iso: string) =>
    new Date(`${iso}T12:00:00`).toLocaleDateString("en-GB", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });

  return (
    <Reveal className="w-full">
      <div className="relative w-full overflow-hidden border border-cream/10 bg-panel/70 px-6 py-10 text-left backdrop-blur-md sm:px-10 md:px-12 md:py-12">
        {/* faint candle glow in the corner */}
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-[radial-gradient(circle,rgba(201,164,92,0.14),transparent_65%)] blur-2xl"
        />

        {status === "success" && confirmation ? (
          /* ── the room is held ─────────────────────────────────────── */
          <div className="relative flex flex-col items-center py-8 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full border border-gold/50 bg-gold/10 text-gold">
              <Check className="h-6 w-6" />
            </span>
            <h3 className="mt-7 font-display text-3xl font-light text-cream md:text-4xl">
              The room is <em className="text-gild italic">held.</em>
            </h3>
            <p className="mt-5 max-w-md text-[14px] font-light leading-relaxed text-sand/85">
              Thank you, {confirmation.name}. Your request for the{" "}
              <span className="text-gold-2">{confirmation.treatment}</span> on{" "}
              <span className="text-gold-2">
                {prettyDate(confirmation.date)}
              </span>{" "}
              has been written into the house book.
            </p>
            <p className="mt-3 max-w-sm text-[12px] font-light leading-relaxed text-muted">
              We will telephone {confirmation.phone} within the day to confirm
              the hour. Until then — breathe slowly.
            </p>
            <button
              onClick={resetForm}
              className="group mt-9 inline-flex items-center gap-3 border-b border-gold/40 pb-2 text-[10px] uppercase tracking-[0.35em] text-gold transition-colors hover:border-gold hover:text-gold-2"
            >
              Book another ritual
            </button>
          </div>
        ) : (
          /* ── the booking form ─────────────────────────────────────── */
          <>
            <div className="relative text-center">
              <p className="flex items-center justify-center gap-4 text-[10px] uppercase tracking-[0.4em] text-gold">
                <Sparkles className="h-3.5 w-3.5" />
                The booking book
              </p>
              <h3 className="mt-5 font-display text-3xl font-light text-cream md:text-4xl">
                Reserve your <em className="text-gild italic">ritual</em>
              </h3>
              <p className="mx-auto mt-4 max-w-md text-[13px] font-light leading-relaxed text-muted">
                Tell us the day and the door you wish to walk through. Every
                request is confirmed by telephone within the day.
              </p>
            </div>

            <RevealLine className="mx-auto mt-8 w-24 bg-gold/40" delay={150} />

            <form
              onSubmit={handleSubmit}
              noValidate
              className="relative mt-10 grid gap-x-8 gap-y-7 sm:grid-cols-2"
            >
              {/* name */}
              <div>
                <label htmlFor="booking-name" className={labelClass}>
                  Your name
                </label>
                <div className="relative">
                  <input
                    id="booking-name"
                    type="text"
                    autoComplete="name"
                    maxLength={100}
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      clearFieldError("name");
                    }}
                    placeholder="Aurelia Guest"
                    aria-invalid={Boolean(fieldErrors.name)}
                    className={cn(fieldClass, fieldErrors.name && fieldErrorClass)}
                  />
                  <FieldIcon icon={User} />
                </div>
                <FieldError message={fieldErrors.name} />
              </div>

              {/* phone */}
              <div>
                <label htmlFor="booking-phone" className={labelClass}>
                  Telephone
                </label>
                <div className="relative">
                  <input
                    id="booking-phone"
                    type="tel"
                    autoComplete="tel"
                    maxLength={20}
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      clearFieldError("phone");
                    }}
                    placeholder="+39 000 000 0000"
                    aria-invalid={Boolean(fieldErrors.phone)}
                    className={cn(fieldClass, fieldErrors.phone && fieldErrorClass)}
                  />
                  <FieldIcon icon={Phone} />
                </div>
                <FieldError message={fieldErrors.phone} />
              </div>

              {/* treatment */}
              <div>
                <label htmlFor="booking-treatment" className={labelClass}>
                  Ritual
                </label>
                <div className="relative">
                  <select
                    id="booking-treatment"
                    value={treatment}
                    onChange={(e) => {
                      setTreatment(e.target.value);
                      clearFieldError("treatment");
                    }}
                    aria-invalid={Boolean(fieldErrors.treatment)}
                    className={cn(
                      fieldClass,
                      "appearance-none",
                      treatment === "" && "text-muted/55",
                      fieldErrors.treatment && fieldErrorClass,
                    )}
                  >
                    <option value="" disabled className="bg-ink text-muted">
                      Choose a ritual
                    </option>
                    {TREATMENTS.map((t) => (
                      <option key={t} value={t} className="bg-ink text-cream">
                        {t}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute bottom-3 right-1 h-3.5 w-3.5 text-gold/80" />
                </div>
                <FieldError message={fieldErrors.treatment} />
              </div>

              {/* date */}
              <div>
                <label htmlFor="booking-date" className={labelClass}>
                  Day of the visit
                </label>
                <div className="relative">
                  <input
                    id="booking-date"
                    type="date"
                    min={today}
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      clearFieldError("date");
                    }}
                    aria-invalid={Boolean(fieldErrors.date)}
                    className={cn(
                      fieldClass,
                      !date && "text-muted/55",
                      fieldErrors.date && fieldErrorClass,
                    )}
                  />
                  <CalendarDays className="pointer-events-none absolute bottom-3 right-1 h-3.5 w-3.5 text-muted/70 sm:hidden" />
                </div>
                <FieldError message={fieldErrors.date} />
              </div>

              {/* message */}
              <div className="sm:col-span-2">
                <label htmlFor="booking-message" className={labelClass}>
                  Notes for the therapists — optional
                </label>
                <textarea
                  id="booking-message"
                  rows={3}
                  maxLength={MESSAGE_LIMIT}
                  value={message}
                  onChange={(e) => {
                    setMessage(e.target.value);
                    clearFieldError("message");
                  }}
                  placeholder="Allergies, a preference for silence, a birthday we should honour…"
                  aria-invalid={Boolean(fieldErrors.message)}
                  className={cn(
                    fieldClass,
                    "resize-none",
                    fieldErrors.message && fieldErrorClass,
                  )}
                />
                <FieldError message={fieldErrors.message} />
              </div>

              {/* server-side error banner */}
              {status === "error" && errorMessage && (
                <div className="flex items-start gap-3 border border-[#d98a6a]/30 bg-[#d98a6a]/8 px-5 py-4 sm:col-span-2">
                  <AlertCircle className="mt-0.5 h-4 w-4 flex-none text-[#d98a6a]" />
                  <p className="text-[12.5px] font-light leading-relaxed text-[#e5a98f]">
                    The booking could not be written — {errorMessage}. Please
                    try once more, or write to us directly at
                    stay@aurelia.spa.
                  </p>
                </div>
              )}

              {/* submit — locked while the wire is warm */}
              <div className="mt-2 flex flex-col items-center gap-4 sm:col-span-2">
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className={cn(
                    "group inline-flex items-center gap-3 border border-gold/50 px-10 py-4 text-[10px] uppercase tracking-[0.38em] text-gold transition-all duration-500",
                    status === "sending"
                      ? "cursor-wait opacity-70"
                      : "hover:bg-gold hover:text-ink",
                  )}
                >
                  {status === "sending" ? (
                    <>
                      <LoaderCircle className="h-4 w-4 animate-spin" />
                      Writing it down
                    </>
                  ) : (
                    "Request this ritual"
                  )}
                </button>
                <p className="text-center text-[10px] font-light tracking-[0.14em] text-muted/80">
                  No payment today — the house confirms every request by
                  telephone first.
                </p>
              </div>
            </form>
          </>
        )}
      </div>
    </Reveal>
  );
}
