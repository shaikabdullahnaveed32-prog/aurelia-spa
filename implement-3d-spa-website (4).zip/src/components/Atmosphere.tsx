import { useEffect, useRef } from "react";
import * as THREE from "three";
import { pointer, reducedMotion } from "../motion/engine";

/* ═══════════════════════════════════════════════════════════════════════
   Atmosphere — a fixed WebGL field of gilded dust. Slow-breathing
   particles drift behind every scene while the camera leans toward the
   cursor, so the whole page shares one quiet, golden air.
   ═══════════════════════════════════════════════════════════════════════ */

export default function Atmosphere() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: false,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.setSize(window.innerWidth, window.innerHeight);
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      55,
      window.innerWidth / window.innerHeight,
      0.1,
      40,
    );
    camera.position.z = 7;

    const COUNT = window.innerWidth < 768 ? 360 : 720;
    const positions = new Float32Array(COUNT * 3);
    const seeds = new Float32Array(COUNT);
    const sizes = new Float32Array(COUNT);

    for (let i = 0; i < COUNT; i++) {
      positions[i * 3] = (Math.random() * 2 - 1) * 8.5;
      positions[i * 3 + 1] = (Math.random() * 2 - 1) * 5.2;
      positions[i * 3 + 2] = (Math.random() * 2 - 1) * 4;
      seeds[i] = Math.random();
      // a rare few particles swell into soft bokeh orbs
      sizes[i] =
        Math.random() < 0.05
          ? 24 + Math.random() * 30
          : 3.5 + Math.random() * 8;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute("aSeed", new THREE.BufferAttribute(seeds, 1));
    geometry.setAttribute("aSize", new THREE.BufferAttribute(sizes, 1));

    const material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
      },
      vertexShader: /* glsl */ `
        attribute float aSeed;
        attribute float aSize;
        uniform float uTime;
        uniform float uPixelRatio;
        varying float vSeed;
        varying float vBreathe;

        void main() {
          vSeed = aSeed;
          vec3 p = position;
          float t = uTime * 0.12;
          p.x += sin(t * (0.6 + aSeed) + aSeed * 40.0) * 0.55;
          p.y += cos(t * (0.8 + aSeed * 0.5) + aSeed * 17.0) * 0.45
               + sin(uTime * 0.05 + aSeed * 6.2831) * 0.3;
          p.z += sin(t * 0.5 + aSeed * 23.0) * 0.4;

          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          float breathe = 0.7 + 0.3 * sin(uTime * (0.5 + aSeed * 1.5) + aSeed * 20.0);
          vBreathe = breathe;
          gl_PointSize = aSize * breathe * uPixelRatio * (300.0 / -mv.z);
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        varying float vSeed;
        varying float vBreathe;

        void main() {
          float d = length(gl_PointCoord - 0.5);
          float alpha = smoothstep(0.5, 0.0, d);
          alpha *= alpha;

          vec3 deep = vec3(0.62, 0.46, 0.2);
          vec3 pale = vec3(0.97, 0.89, 0.67);
          vec3 color = mix(deep, pale, vSeed);

          float strength = mix(0.08, 0.5, fract(vSeed * 7.31));
          gl_FragColor = vec4(color, alpha * strength * vBreathe);
        }
      `,
    });

    const points = new THREE.Points(geometry, material);
    scene.add(points);

    let rafId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      const t = clock.getElapsedTime();
      material.uniforms.uTime.value = reducedMotion ? 0 : t;
      points.rotation.y = reducedMotion ? 0 : t * 0.012;

      // the camera itself leans toward the cursor — depth you can feel
      camera.position.x += (pointer.sx * 0.55 - camera.position.x) * 0.045;
      camera.position.y += (-pointer.sy * 0.4 - camera.position.y) * 0.045;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(animate);
    };
    animate();

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", onResize);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
      mount.removeChild(renderer.domElement);
    };
  }, []);

  return (
    <div
      ref={mountRef}
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
