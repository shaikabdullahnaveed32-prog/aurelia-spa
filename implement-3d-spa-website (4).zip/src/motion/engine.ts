import { useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════════════════
   Aurelia motion engine — a single shared rAF loop and a globally
   smoothed pointer, so every layer, card and particle reads the same
   buttery cursor signal instead of fighting for their own listeners.
   ═══════════════════════════════════════════════════════════════════════ */

export const reducedMotion =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Raw + smoothed pointer, normalised to -1 … 1 across the viewport. */
export const pointer = {
  x: 0,
  y: 0,
  sx: 0,
  sy: 0,
  active: false,
};

if (typeof window !== "undefined") {
  window.addEventListener(
    "pointermove",
    (e) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
      pointer.active = true;
    },
    { passive: true },
  );
}

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const clamp = (v: number, min: number, max: number) =>
  Math.min(max, Math.max(min, v));

type FrameCb = (t: number, dt: number) => void;

const subscribers = new Set<FrameCb>();
let rafId = 0;
let last = 0;

const loop = (t: number) => {
  const dt = Math.min(50, t - last || 16.7);
  last = t;

  // framerate-independent exponential smoothing — the "weight" of the cursor
  const k = reducedMotion ? 1 : 1 - Math.pow(0.0012, dt / 1000);
  pointer.sx += (pointer.x - pointer.sx) * k;
  pointer.sy += (pointer.y - pointer.sy) * k;

  subscribers.forEach((cb) => cb(t, dt));
  rafId = requestAnimationFrame(loop);
};

export function onFrame(cb: FrameCb): () => void {
  subscribers.add(cb);
  if (subscribers.size === 1) {
    last = performance.now();
    rafId = requestAnimationFrame(loop);
  }
  return () => {
    subscribers.delete(cb);
    if (subscribers.size === 0) cancelAnimationFrame(rafId);
  };
}

/** Subscribe a callback to the shared loop. Safe to pass inline closures. */
export function useFrame(cb: FrameCb) {
  const ref = useRef(cb);
  ref.current = cb;
  useEffect(() => onFrame((t, dt) => ref.current(t, dt)), []);
}

/** Adds `is-inview` to the element the first time it enters the viewport. */
export function useInView<T extends HTMLElement = HTMLDivElement>(
  threshold = 0.18,
  rootMargin = "0px 0px -8% 0px",
) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-inview");
            io.unobserve(entry.target);
          }
        }
      },
      { threshold, rootMargin },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, rootMargin]);
  return ref;
}

/** Gives every `[data-depth]` descendant a cursor-driven translate3d drift. */
export function useDepthParallax<T extends HTMLElement = HTMLDivElement>(
  gain = 1,
) {
  const ref = useRef<T>(null);
  const nodes = useRef<HTMLElement[]>([]);

  useEffect(() => {
    nodes.current = Array.from(
      ref.current?.querySelectorAll<HTMLElement>("[data-depth]") ?? [],
    );
  }, []);

  useFrame(() => {
    const px = reducedMotion ? 0 : pointer.sx * gain;
    const py = reducedMotion ? 0 : pointer.sy * gain;
    for (const n of nodes.current) {
      const d = parseFloat(n.dataset.depth ?? "0");
      n.style.transform = `translate3d(${px * d * 56}px, ${
        py * d * 40
      }px, 0)`;
    }
  });

  return ref;
}
